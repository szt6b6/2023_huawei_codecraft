#define _CRT_SECURE_NO_WARNINGS
#include"globalVariables.h"
//#include<Windows.h>

int main() {
    //��ʼ��
	for (int i = 0; i < 50; i++) {
		for (int j = 0; j < 8; j++) {
			sell_benchs_in_queue[i][j] = false;
		}
		buy_benchs_in_queue[i] = false;
	}
    readMap();
    puts("OK");
    fflush(stdout);
    //LPCTSTR lpszUnicode = "Test String";
    //MessageBox(NULL, lpszUnicode,lpszUnicode, MB_YESNO);
    while (scanf("%d", &frameID) != EOF) {
        //��ȡ��ͼ��Ϣ
        readState();
		//���ݲ�ͬ�ĵ�ͼ�������
		if (deskNum == 18) { 
			count_have_materials_weight = 0; 
			to_sell_need_frames_error = 0; 
			to_buy_need_frames_error = 0;
		}//map4
		else if (deskNum == 50) { 
			count_have_materials_weight = 0; 
			produce_done_status_weight = 0; 
			sell_bench_logical_dist_estimate = 150; 
			estimate_end_frame = 8600;
		}//map3
		else if (deskNum == 25) { 
			count_have_materials_weight = 24; 
			produce_done_status_weight = 50; 
			map_2_flag = true;
			estimate_end_frame = 8600;
		}//map2
		else { 
			count_have_materials_weight = 10;  
			produce_done_status_weight = 0; 
			map_2_flag = true;
		}//map1
        //���������״̬����
        calculateRobotState();
        //eventDeal();
        //���Ŀ�깤��̨�Ͷ�������
		update_queue();

		printf("%d\n", frameID);

		run_task();

		/*	fprintf(stderr, "aimDeck: robot 0 to bench: %d\n", aimDesk[0]);
			fprintf(stderr, "aimDeck: robot 1 to bench: %d\n", aimDesk[1]);
			fprintf(stderr, "aimDeck: robot 2 to bench: %d\n", aimDesk[2]);
			fprintf(stderr, "aimDeck: robot 3 to bench: %d\n", aimDesk[3]);
		*/

        //ȫ���ٶȿ���
        speedControl();
        //�����㷨
        avoidOb();
        //���ָ��
        outCMD();
    }
    return 0;
}
